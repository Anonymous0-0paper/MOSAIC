from django.apps import AppConfig


class EdgeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EdgeApp'
