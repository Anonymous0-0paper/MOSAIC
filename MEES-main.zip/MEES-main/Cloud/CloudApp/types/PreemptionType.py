from enum import Enum


class PreemptionType(Enum):
    Eager = "Eager",
    Lazy = "Lazy"
